// BEN Admin Panel JavaScript
const logsContainer = document.getElementById('logs');
const consoleOutput = document.getElementById('console-output');
const statusEl = document.getElementById('status');
const statusText = document.getElementById('status-text');

let logsPollInterval = null;

// Toggle password visibility
function togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
}

// Add log to terminal
function addLog(message, type = 'info', container = logsContainer) {
    const line = document.createElement('div');
    line.className = 'terminal-line';
    const time = new Date().toLocaleTimeString();
    const outputClass = type === 'error' ? 'error' : type === 'success' ? 'success' : type === 'warning' ? 'warning' : '';
    line.innerHTML = `<span class="timestamp">[${time}]</span><span class="output ${outputClass}">${escapeHtml(message)}</span>`;
    container.appendChild(line);
    container.scrollTop = container.scrollHeight;
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Clear logs
function clearLogs() {
    logsContainer.innerHTML = '<div class="terminal-line"><span class="timestamp">[System]</span><span class="output">Logs cleared</span></div>';
}

// Load configuration from server
async function loadConfig() {
    try {
        const response = await fetch('/admin/config', {
            method: 'GET',
            credentials: 'same-origin'
        });

        if (response.status === 401 || response.redirected) {
            window.location.href = '/admin/login';
            return;
        }

        if (response.ok) {
            const config = await response.json();

            // Load AI models config
            if (config.additionalConfig) {
                document.getElementById('grok-key').value = config.additionalConfig.grokApiKey || '';
                document.getElementById('grok-model').value = config.additionalConfig.grokModel || 'grok-beta';
                document.getElementById('claude-key').value = config.additionalConfig.claudeApiKey || '';
                document.getElementById('claude-model').value = config.additionalConfig.claudeModel || 'claude-3-5-sonnet-20241022';
                document.getElementById('system-instructions').value = config.additionalConfig.systemInstructions || 'You are a helpful AI assistant aligned with Torah principles.';
            }

            // Load BEN integration config
            if (config.benIntegration) {
                document.getElementById('ben-url').value = config.benIntegration.serviceUrl || '';
                document.getElementById('ben-token').value = config.benIntegration.apiToken || '';
                document.getElementById('webhook-url').value = config.benIntegration.webhookUrl || '';
                document.getElementById('ben-config').value = config.benIntegration.jsonConfig || '';
            }

            addLog('✓ Configuration loaded', 'success');
        } else {
            addLog('⚠ Failed to load configuration', 'warning');
        }
    } catch (error) {
        addLog(`✗ Error loading config: ${error.message}`, 'error');
    }
}

// Save configuration
async function saveConfig() {
    const config = {
        benIntegration: {
            serviceUrl: document.getElementById('ben-url').value,
            apiToken: document.getElementById('ben-token').value,
            webhookUrl: document.getElementById('webhook-url').value,
            jsonConfig: document.getElementById('ben-config').value
        },
        additionalConfig: {
            grokApiKey: document.getElementById('grok-key').value,
            grokModel: document.getElementById('grok-model').value,
            claudeApiKey: document.getElementById('claude-key').value,
            claudeModel: document.getElementById('claude-model').value,
            torahMode: true,
            systemInstructions: document.getElementById('system-instructions').value
        }
    };

    try {
        const response = await fetch('/admin/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'same-origin',
            body: JSON.stringify(config)
        });

        if (response.status === 401 || response.redirected) {
            window.location.href = '/admin/login';
            return;
        }

        if (response.ok) {
            addLog('✓ Configuration saved successfully', 'success');
            const indicator = document.getElementById('save-indicator');
            indicator.classList.add('show');
            setTimeout(() => indicator.classList.remove('show'), 2000);
        } else {
            addLog('✗ Failed to save configuration', 'error');
        }
    } catch (error) {
        addLog(`✗ Error: ${error.message}`, 'error');
    }
}

// Test BEN connection
async function testConnection() {
    const benUrl = document.getElementById('ben-url').value;
    if (!benUrl) {
        addLog('⚠ BEN Service URL not configured', 'warning');
        return;
    }

    addLog('Testing connection to BEN service...', 'info');

    try {
        const response = await fetch('/admin/test-connection', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'same-origin',
            body: JSON.stringify({ service: 'ben', url: benUrl })
        });

        if (response.status === 401 || response.redirected) {
            window.location.href = '/admin/login';
            return;
        }

        const result = await response.json();
        if (result.success) {
            addLog(`✓ ${result.message}`, 'success');
        } else {
            addLog(`✗ ${result.message}`, 'error');
        }
    } catch (error) {
        addLog(`✗ Connection test failed: ${error.message}`, 'error');
    }
}

// Submit prompt to BEN Console
async function submitPrompt() {
    const prompt = document.getElementById('ben-prompt').value.trim();
    const mode = document.getElementById('ben-mode').value;

    if (!prompt) {
        addLog('⚠ Please enter a prompt', 'warning');
        return;
    }

    const submitBtn = document.getElementById('submit-btn');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span>⏳</span> Processing...';

    consoleOutput.style.display = 'block';
    consoleOutput.innerHTML = '<div class="terminal-line"><span class="timestamp">[Console]</span><span class="output">Processing prompt...</span></div>';

    try {
        const response = await fetch('/admin/ben/console', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'same-origin',
            body: JSON.stringify({ prompt, mode })
        });

        if (response.status === 401 || response.redirected) {
            window.location.href = '/admin/login';
            return;
        }

        const result = await response.json();

        if (result.success) {
            consoleOutput.innerHTML = '';
            addLog(`Model: ${result.model} (${result.provider})`, 'success', consoleOutput);
            addLog('Response:', 'info', consoleOutput);
            addLog(result.response, 'info', consoleOutput);
            addLog(`✓ Prompt processed successfully using ${result.provider}`, 'success');
        } else {
            consoleOutput.innerHTML = '';
            addLog(`Error: ${result.error}`, 'error', consoleOutput);
            if (result.details) {
                addLog(`Details: ${result.details}`, 'error', consoleOutput);
            }
            addLog('✗ Failed to process prompt', 'error');
        }
    } catch (error) {
        consoleOutput.innerHTML = '';
        addLog(`Error: ${error.message}`, 'error', consoleOutput);
        addLog(`✗ Request failed: ${error.message}`, 'error');
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<span>🚀</span> Submit';
    }
}

// Load logs from server
async function loadLogs() {
    try {
        const response = await fetch('/admin/logs', {
            method: 'GET',
            credentials: 'same-origin'
        });

        if (response.status === 401 || response.redirected) {
            window.location.href = '/admin/login';
            return;
        }

        if (response.ok) {
            const data = await response.json();
            if (data.logs && data.logs.length > 0) {
                // Only update if logs have changed
                const currentLogs = logsContainer.innerHTML;
                const newLogsHtml = data.logs.map(log => {
                    const time = new Date().toLocaleTimeString();
                    return `<div class="terminal-line"><span class="timestamp">[${time}]</span><span class="output">${escapeHtml(log)}</span></div>`;
                }).join('');

                if (currentLogs !== newLogsHtml) {
                    logsContainer.innerHTML = newLogsHtml;
                    logsContainer.scrollTop = logsContainer.scrollHeight;
                }
            }
        }
    } catch (error) {
        // Silently fail for polling requests
        console.error('Error loading logs:', error);
    }
}

// Logout function
async function logout() {
    try {
        const response = await fetch('/admin/logout', {
            method: 'POST',
            credentials: 'same-origin'
        });

        if (response.ok || response.redirected) {
            window.location.href = '/admin/login';
        }
    } catch (error) {
        window.location.href = '/admin/login';
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    addLog('BEN Admin Panel initialized', 'success');
    loadConfig();

    // Start polling logs every 10 seconds
    loadLogs();
    logsPollInterval = setInterval(loadLogs, 10000);

    // Handle Enter key in prompt textarea
    document.getElementById('ben-prompt').addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 'Enter') {
            submitPrompt();
        }
    });
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (logsPollInterval) {
        clearInterval(logsPollInterval);
    }
});
