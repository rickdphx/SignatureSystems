const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || 'change-this-secret-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: false, // Set to true if using HTTPS
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Logging middleware
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  const logMessage = `${timestamp} - ${req.method} ${req.url}`;
  console.log(logMessage);

  // Write to log file
  const logPath = path.join(__dirname, 'logs', 'app.log');
  fs.appendFile(logPath, logMessage + '\n', (err) => {
    if (err) console.error('Failed to write log:', err);
  });

  next();
});

// Auth middleware
function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated) {
    return next();
  }
  res.redirect('/admin/login');
}

// Login routes
app.get('/admin/login', (req, res) => {
  if (req.session && req.session.authenticated) {
    return res.redirect('/admin/');
  }
  res.sendFile(path.join(__dirname, 'public', 'admin', 'login.html'));
});

app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  const correctUsername = process.env.BEN_ADMIN_USERNAME || 'admin';
  const correctPassword = process.env.BEN_ADMIN_PASSWORD || 'admin123';

  if (username === correctUsername && password === correctPassword) {
    req.session.authenticated = true;
    req.session.username = username;
    res.redirect('/admin/');
  } else {
    res.redirect('/admin/login?error=1');
  }
});

app.post('/admin/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Error destroying session:', err);
    }
    res.redirect('/admin/login');
  });
});

// Serve static files from public directory
app.use(express.static(path.join(__dirname, 'public')));

// Protected admin page
app.get('/admin/', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin', 'admin.html'));
});

app.get('/admin', requireAuth, (req, res) => {
  res.redirect('/admin/');
});

// Admin API routes (protected)
const adminRoutes = require('./server/adminRoutes');
app.use('/admin', requireAuth, adminRoutes);

// Also mount admin routes at /api/ for API calls from admin UI
app.use('/api', adminRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Error handling
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

app.listen(PORT, HOST, () => {
  console.log(`
╔═══════════════════════════════════════════════════════╗
║           BEN Admin Server Running                   ║
╚═══════════════════════════════════════════════════════╝

🌐 Server: ${HOST}:${PORT}
🔐 Admin Login: http://localhost:${PORT}/admin/login
📁 Public Directory: ${path.join(__dirname, 'public')}
📁 Logs Directory: ${path.join(__dirname, 'logs')}

Environment Variables:
  - BEN_ADMIN_USERNAME: ${process.env.BEN_ADMIN_USERNAME || 'admin (default)'}
  - BEN_ADMIN_PASSWORD: ${process.env.BEN_ADMIN_PASSWORD ? '***set***' : 'admin123 (default)'}
  - SESSION_SECRET: ${process.env.SESSION_SECRET ? '***set***' : 'using default (change in production!)'}

Health Check: http://localhost:${PORT}/health
  `);
});
