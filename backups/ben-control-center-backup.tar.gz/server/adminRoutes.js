const express = require('express');
const router = express.Router();
const fs = require('fs').promises;
const path = require('path');
const axios = require('axios');

const CONFIG_PATH = path.join(__dirname, '../config/ben-admin.config.json');
const LOGS_PATH = path.join(__dirname, '../logs/app.log');

// Load configuration
async function loadConfig() {
  try {
    const data = await fs.readFile(CONFIG_PATH, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    // Create default config if not exists
    const defaultConfig = {
      benIntegration: {
        serviceUrl: '',
        apiToken: '',
        webhookUrl: '',
        jsonConfig: ''
      },
      additionalConfig: {
        grokApiKey: '',
        grokModel: 'grok-beta',
        claudeApiKey: '',
        claudeModel: 'claude-3-5-sonnet-20241022',
        torahMode: true,
        systemInstructions: 'You are a helpful AI assistant aligned with Torah principles.'
      },
      integrations: {}
    };
    await saveConfig(defaultConfig);
    return defaultConfig;
  }
}

// Save configuration (atomic write)
async function saveConfig(config) {
  const tmpPath = CONFIG_PATH + '.tmp';
  await fs.writeFile(tmpPath, JSON.stringify(config, null, 2), 'utf8');
  await fs.rename(tmpPath, CONFIG_PATH);
}

// GET /admin/config - Return config with masked passwords
router.get('/config', async (req, res) => {
  try {
    const config = await loadConfig();

    // Mask sensitive fields
    const safeConfig = {
      benIntegration: {
        serviceUrl: config.benIntegration.serviceUrl,
        apiToken: config.benIntegration.apiToken ? '********' : '',
        webhookUrl: config.benIntegration.webhookUrl,
        jsonConfig: config.benIntegration.jsonConfig
      },
      additionalConfig: {
        grokApiKey: config.additionalConfig.grokApiKey ? '********' : '',
        grokModel: config.additionalConfig.grokModel,
        claudeApiKey: config.additionalConfig.claudeApiKey ? '********' : '',
        claudeModel: config.additionalConfig.claudeModel,
        torahMode: config.additionalConfig.torahMode,
        systemInstructions: config.additionalConfig.systemInstructions
      },
      integrations: config.integrations
    };

    res.json(safeConfig);
  } catch (error) {
    console.error('Error loading config:', error);
    res.status(500).json({ error: 'Failed to load configuration' });
  }
});

// POST /admin/config - Update config
router.post('/config', async (req, res) => {
  try {
    const currentConfig = await loadConfig();
    const updates = req.body;

    // Merge updates (only update non-masked fields)
    if (updates.benIntegration) {
      if (updates.benIntegration.serviceUrl !== undefined) {
        currentConfig.benIntegration.serviceUrl = updates.benIntegration.serviceUrl;
      }
      if (updates.benIntegration.apiToken && updates.benIntegration.apiToken !== '********') {
        currentConfig.benIntegration.apiToken = updates.benIntegration.apiToken;
      }
      if (updates.benIntegration.webhookUrl !== undefined) {
        currentConfig.benIntegration.webhookUrl = updates.benIntegration.webhookUrl;
      }
      if (updates.benIntegration.jsonConfig !== undefined) {
        currentConfig.benIntegration.jsonConfig = updates.benIntegration.jsonConfig;
      }
    }

    if (updates.additionalConfig) {
      if (updates.additionalConfig.grokApiKey && updates.additionalConfig.grokApiKey !== '********') {
        currentConfig.additionalConfig.grokApiKey = updates.additionalConfig.grokApiKey;
      }
      if (updates.additionalConfig.grokModel !== undefined) {
        currentConfig.additionalConfig.grokModel = updates.additionalConfig.grokModel;
      }
      if (updates.additionalConfig.claudeApiKey && updates.additionalConfig.claudeApiKey !== '********') {
        currentConfig.additionalConfig.claudeApiKey = updates.additionalConfig.claudeApiKey;
      }
      if (updates.additionalConfig.claudeModel !== undefined) {
        currentConfig.additionalConfig.claudeModel = updates.additionalConfig.claudeModel;
      }
      if (updates.additionalConfig.torahMode !== undefined) {
        currentConfig.additionalConfig.torahMode = updates.additionalConfig.torahMode;
      }
      if (updates.additionalConfig.systemInstructions !== undefined) {
        currentConfig.additionalConfig.systemInstructions = updates.additionalConfig.systemInstructions;
      }
    }

    await saveConfig(currentConfig);
    res.json({ success: true, message: 'Configuration saved successfully' });
  } catch (error) {
    console.error('Error saving config:', error);
    res.status(500).json({ error: 'Failed to save configuration' });
  }
});

// POST /admin/test-connection - Test BEN service connection
router.post('/test-connection', async (req, res) => {
  try {
    const config = await loadConfig();
    const { serviceUrl, apiToken } = config.benIntegration;

    if (!serviceUrl) {
      return res.json({ success: false, message: 'Service URL not configured' });
    }

    // Test health endpoint
    const healthUrl = serviceUrl.endsWith('/') ? serviceUrl + 'health' : serviceUrl + '/health';
    const response = await axios.get(healthUrl, {
      headers: apiToken ? { 'Authorization': `Bearer ${apiToken}` } : {},
      timeout: 5000
    });

    res.json({
      success: true,
      status: response.status,
      message: 'Connection successful',
      data: response.data
    });
  } catch (error) {
    res.json({
      success: false,
      message: error.message || 'Connection failed'
    });
  }
});

// GET /admin/logs - Return last 200 lines of logs
router.get('/logs', async (req, res) => {
  try {
    const data = await fs.readFile(LOGS_PATH, 'utf8');
    const lines = data.split('\n').filter(line => line.trim());
    const lastLines = lines.slice(-200);
    res.json({ logs: lastLines });
  } catch (error) {
    // If log file doesn't exist, return empty
    res.json({ logs: [] });
  }
});

// POST /admin/ben/console - Handle BEN Console prompts
router.post('/ben/console', async (req, res) => {
  try {
    const { prompt, mode } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const config = await loadConfig();
    const { grokApiKey, grokModel, claudeApiKey, claudeModel, torahMode, systemInstructions } = config.additionalConfig;

    // Determine which AI to use based on mode
    let useGrok = true;
    if (mode === 'deep' || mode === 'research') {
      useGrok = false;
    }

    let systemPrompt = systemInstructions;

    // Add mode-specific instructions
    if (mode === 'torah') {
      systemPrompt = 'You are a Torah-aligned AI assistant. All responses must align with Torah principles and Jewish wisdom.';
    } else if (mode === 'execute') {
      systemPrompt = 'Haríts mode: Execute the task immediately without discussion or explanation. Be direct and action-oriented.';
    } else if (mode === 'deep') {
      systemPrompt = 'Deep reasoning mode: Provide thorough analysis with detailed reasoning and multiple perspectives.';
    } else if (mode === 'research') {
      systemPrompt = 'Research mode: Provide comprehensive, well-researched information with citations and sources.';
    }

    let response;

    if (useGrok) {
      // Use Grok API (X.AI)
      if (!grokApiKey) {
        return res.status(400).json({ error: 'Grok API key not configured' });
      }

      response = await axios.post('https://api.x.ai/v1/chat/completions', {
        model: grokModel,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: prompt }
        ]
      }, {
        headers: {
          'Authorization': `Bearer ${grokApiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 30000
      });

      res.json({
        success: true,
        response: response.data.choices[0].message.content,
        model: grokModel,
        provider: 'grok'
      });
    } else {
      // Use Claude API (Anthropic)
      if (!claudeApiKey) {
        return res.status(400).json({ error: 'Claude API key not configured' });
      }

      response = await axios.post('https://api.anthropic.com/v1/messages', {
        model: claudeModel,
        max_tokens: 4096,
        messages: [
          { role: 'user', content: prompt }
        ],
        system: systemPrompt
      }, {
        headers: {
          'x-api-key': claudeApiKey,
          'anthropic-version': '2023-06-01',
          'Content-Type': 'application/json'
        },
        timeout: 30000
      });

      res.json({
        success: true,
        response: response.data.content[0].text,
        model: claudeModel,
        provider: 'claude'
      });
    }
  } catch (error) {
    console.error('BEN Console error:', error.response?.data || error.message);
    res.status(500).json({
      error: 'Failed to process prompt',
      details: error.response?.data?.error?.message || error.message
    });
  }
});

module.exports = router;
